//********************************************************************
//  Diamond.java        Java Foundations
//
//  Solution to Programming Project 1.7
//********************************************************************

public class Diamond
{
   //-----------------------------------------------------------------
   //  Prints a diamond shape.
   //-----------------------------------------------------------------
   public static void main (String args[])
   {
      System.out.println("    *");
      System.out.println("   ***");
      System.out.println("  *****");
      System.out.println(" *******");
      System.out.println("*********");
      System.out.println(" *******");
      System.out.println("  *****");
      System.out.println("   ***");
      System.out.println("    *");
    }

}