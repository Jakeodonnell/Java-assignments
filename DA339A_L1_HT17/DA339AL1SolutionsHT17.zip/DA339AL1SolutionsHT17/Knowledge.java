//********************************************************************
//  Knowledge.java        Java Foundations
//
//  Solution to Programming Project 1.4 
//********************************************************************

public class Knowledge
{
   //-----------------------------------------------------------------
   //  Prints a phrase in various configurations.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ();
      System.out.println ("Knowledge is Power");
      System.out.println ();
      System.out.println ();
      System.out.println ("Knowledge");
      System.out.println ("   is");
      System.out.println ("  Power");
      System.out.println ();
      System.out.println ();
      System.out.println ("==========================");
      System.out.println ("|                        |");
      System.out.println ("|   Knowledge is Power   |");
      System.out.println ("|                        |");
      System.out.println ("==========================");
      System.out.println ();
   }
}
