//********************************************************************
//  Test.java        Java Foundations
//
//  Solution to Programming Project 1.1 
//********************************************************************

public class Test
{
   //-----------------------------------------------------------------
   //  Prints a statement.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ("An Emergency Broadcast");
   }
}
